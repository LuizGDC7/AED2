#include <stdio.h>
#include <string.h>

#define ll long long

int main(){

    char buffer[100] = "\n";

/*
    sprintf(buffer, "Teste 1: %.2lf\n", 7.0 / 9);

    printf("Valor armazenado:\n%s => tamanho: %lld\n", buffer, strlen(buffer));

    sprintf(buffer, "Teste 79 rapinihp: %.2lf\n", 49 / 9);

    printf("Valor armazenado:\n%s => tamanho: %lld\n", buffer, strlen(buffer));
*/
    printf("lenght: %d\n", strlen(buffer));

    return 0;
}