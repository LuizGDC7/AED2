#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "encap_png.h"
#include "linked_list.h"

int main(){

    c_linkedl lista = create_c_list();
    c_linkedl* endereco = &lista;
    for(int c = 0; c < 10; c++){
        insert_c_list(&lista, create_node(c));
    }

    show_c_list(&lista);
    printf("\n%d\n", endereco->tamanho);

    

    return 0;
}